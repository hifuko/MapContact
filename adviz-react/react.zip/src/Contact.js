import React, {Component} from 'react';
import store from './redux/store';
import { click_contact } from './redux/actions'
import { connect } from 'react-redux'


class Contact extends Component{
   
    handleClick = (e) => {
        let key = this.props.id
        console.log("==========================Contact: " + key)

        let text = localStorage.getItem(key);
        let obj = JSON.parse(text);

        let firstName = document.querySelector("#fn");
        let name = document.querySelector("#n");
        let street = document.querySelector("#street");
        let postCode = document.querySelector("#pc");
        let city = document.querySelector("#city");
        let country = document.querySelector("#country");
        let private_ = document.querySelector("#pr");


        firstName.value = obj.firstName;
        name.value = obj.name;
        street.value = obj.street;
        postCode.value = obj.postCode;
        city.value = obj.city;
        country.value = obj.country;
        private_.checked = obj.private_;

        //normalo can only read contact info
        if (sessionStorage.getItem("currentUserRole") === "user") {
            firstName.disabled = "disabled";
            name.disabled = "disabled";
            street.disabled = "disabled";
            postCode.disabled = "disabled";
            city.disabled = "disabled";
            country.disabled = "disabled";
            private_.disabled = "disabled";

        }


        let objects = this.props.objects
        let index = 100

        for (let i = 0; i < objects.length; i++) {
            if (objects[i] != null) {
                if (objects[i].firstName===obj.firstName && objects[i].name===obj.name) {
                    index = i
                }
            }
            
        }


       // this.props.clickContact(key, index)
        const key_index = {
            key: key,
            index: index
        }
        this.props.click_contact(key_index)



        document.querySelector("#addNewAddress").style.display = "none";
        document.querySelector("#main").style.display = "none";
        document.querySelector("#updateDeleteAddress").style.display = "block";
    }


    render(){

        //let key = "person_" + this.props.firstName + " " + this.props.name
        return(
           
            <li onClick={this.handleClick} id={this.props.id}>{this.props.obj.firstName + " " + this.props.obj.name}</li>
            //<li onClick={this.props.handleAddContact([...this.props.objects, )}>name:{this.props.obj.firstName + " " + this.props.obj.name}</li>

        );
      }
    
    
}


export default connect(
    state=>state,
    {click_contact}
  )(Contact);