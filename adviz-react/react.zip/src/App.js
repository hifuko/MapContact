import React, { Component } from 'react';
import PubSub from 'pubsub-js';
import { BrowserRouter, Switch, Route } from 'react-router-dom';
import Login from './components/login/Login';
import ProtectedRoute from './components/routing/ProtectedRoutes';



import './App.css';
import Main from './Main';
import Add from './Add';
import UpdateDelete from './UpdateDelete';
import store from './redux/store'
import {ADD_CONTACT} from './redux/actionTypes'


class App extends Component {


  // constructor(props){
  //   super(props)

    // let objs = []

    // let len = localStorage.length;
    //   for (let i = 0; i < len; i++) {
    //     let key = localStorage.key(i);
    //     if (key.startsWith("person_")) {

    //       let text = localStorage.getItem(key);
    //       let obj = JSON.parse(text);
    //       objs.push(obj)
          
    //     }
    //   }

      


      // this.state = {
      //   loggedin: false,
      //   addresses: [],
      //   objects: objs,
      //   contact_id: "",
      //   index: -1
  
      // }
  
   
 // }

  //still doesn't work well
  // componentDidMount(){
  //   console.log("miao3");
  //   if (sessionStorage.getItem("loggedIn") === "true") {
  //     document.querySelector("#login").style.display = "none";
  //     document.querySelector("#main").style.display = "block";
  //     console.log("miao1");

  //     if (sessionStorage.getItem("currentUserRole") === "user") {
  //         console.log("miao");
  //         //normalo don't have add, update, delete buttons
  //         document.querySelector("#add_menu_btn").style.display = "none";
  //         document.querySelector("#update").style.display = "none";
  //         document.querySelector("#delete").style.display = "none";

  //     }
  //   }
  // }
  
  

  // handleAddContact(contact){
  //   const contacts = store.objects //getState
  //   contacts.push(contact)
  //   // this.setState({
  //   //   objects: contacts
  //   // })

  //   store.dispatch({type: ADD_CONTACT, data: contact})

  //   document.querySelector("#main").style.display = "none";
  //   document.querySelector("#addNewAddress").style.display = "block";
  // }

  // clickContact(contact_id, index){
  //    this.setState({
  //      contact_id: contact_id,
  //      index: index
  //    })
    

  // }
  
  // update(index, contact){
  //   const contacts = this.state.objects
  //   contacts[index] = contact
  //   this.setState({
  //     objects: contacts
  //   })

  //   document.querySelector("#main").style.display = "block";
  //   document.querySelector("#updateDeleteAddress").style.display = "none";

  // }

  // delete(index){
  //   const contacts = this.state.objects
  //   delete contacts[index]
  //   this.setState({
  //     objects: contacts
  //   })

  //   document.querySelector("#main").style.display = "block";
  //   document.querySelector("#updateDeleteAddress").style.display = "none";

  // }

  // componentDidMount(){
  //   PubSub.subscribe("update", (msg, data) => {
  //     this.update(data.index, data.myObj)
  //   })

  //   PubSub.subscribe("delete", (msg, index) => {
  //     this.delete(index)
  //   })


  // }

  render(){
  
    return(

      // <BrowserRouter>
      //   <div className="App">
      //     <Switch>
      //       <Route path='/login' component={Login} />
      //       <Route path='/main' component={Main} />
      //       <ProtectedRoute path='/add' component={Add} />
      //       <ProtectedRoute path='/:address_id' component={UpdateDelete} />
      //     </Switch>
      //   </div>
      // </BrowserRouter>
  
      // <BrowserRouter>
      // <div>
      //   <Login></Login>
      //   <Main objects={this.state.objects} clickContact={(contact_id, index) => this.clickContact(contact_id, index)}/>
      //   <Add objects={this.state.objects} handleAddContact={(contact) => this.handleAddContact(contact)}/>
      //   <UpdateDelete objects={this.state.objects} contact_id={this.state.contact_id} index={this.state.index}/>
      // </div>
      // </BrowserRouter>

      <BrowserRouter>
      <div>
        <Login/>
        <Main />
        <Add />
        <UpdateDelete />
      </div>
      </BrowserRouter>
      
      
    )
      
     
  }


}


export default App;
