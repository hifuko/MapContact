import React, {Component} from 'react';
import Contact from './Contact';
import MapView from './components/map/MapView.js';
import { connect } from 'react-redux'
import { add_contact } from './redux/actions'




class Main extends Component{
   

    handleClick = (e) => {
        //e.preventDefault()
        
        document.querySelector("#main").style.display = "none";
        document.querySelector("#addNewAddress").style.display = "block";
   }

//    this.objects.map(obj => { 
//     if (sessionStorage.getItem("currentUserRole") === "admin") {
//         return <Contact id={"person_" + obj.firstName + " " + obj.name} obj={obj} objects={this.props.objects} 
//                 clickContact={(contact_id, index) => this.props.clickContact(contact_id, index)}/>
          

//     } else{
//         if (obj.private_ === false) {
//             return <Contact id={"person_" + obj.firstName + " " + obj.name} obj={obj} objects={this.props.objects} 
//                 clickContact={(contact_id, index) => this.props.clickContact(contact_id, index)}/>
          
//         } else{
//             return null
//         }
//     }
       
             
                
//                 })    

    // componentDidMount(){
    //     this.props.subscribe(this.render)
    // }


      
    render(){
            
        console.log("===================main: " + this.props.objects)
        
        return(
            <section id="main">        
                <main>
                    <h1>Main</h1>
                
                    <div class="buttonbar">
                        <input id="add_menu_btn" class="btn" type="submit" onClick={this.handleClick} value="Add Contact"/>
                        {/* <input id="add_menu_btn" class="btn" type="submit" onClick={() => this.props.handleAddContact()} value="Add Contact"/> */}

                    </div>
                
                    <div class="mainscreen">
                        <div class="adresslist">
                            <ul id="adresses"> 
                               {
                                    
                                    this.props.objects.map(obj => { 
                                        return <Contact id={"person_" + obj.firstName + " " + obj.name} obj={obj} objects={this.props.objects}/>
                                                           
                                    })
                                }
                                    
                        
                                
                            </ul>
                        </div>
                        <div class="map">
                            <MapView />
                        </div>
                    </div>
            
                </main>
            
          </section>
        );
      } 
}



export default connect(
    state => state,
    {add_contact}
  )(Main);