import {ADD_CONTACT, UPDATE, CLICK_CONTACT, DELETE} from './actionTypes'
import store from './store';
import {combineReducers} from 'redux'

let objs = []



    let len = localStorage.length;
      for (let i = 0; i < len; i++) {
        let key = localStorage.key(i);
        if (key.startsWith("person_")) {

          let text = localStorage.getItem(key);
          let obj = JSON.parse(text);
          objs.push(obj)
          
        }
      }


const initState = {
    loggedin: false,
    addresses: [],
    objects: objs,
    contact_id: "",
    index: -1
};

// function rootReducer (state = initState, action) {
//     // if(action.type === "LOGIN") {
//     //     return initState;
//     // }
//     console.log("=================type: " + initState.objects)
//     return initState;
// };


export default function reducer(state = initState, action) {
    console.log('reducer()', state, action)
    switch (action.type) {
        case ADD_CONTACT:
            const contacts = state.objects 
            contacts.push(action.payload)
            
            return {
                objects: contacts
            };
        case CLICK_CONTACT:
            return {
                ...state,
                contact_id: action.payload.key,
                index: action.payload.index
            };    
        case UPDATE:
            const contacts2 = state.objects 
            contacts2[state.index] = action.payload
            return {
                objects: contacts2
            }    
        case DELETE:
            const contacts3 = state.objects
            delete contacts3[state.index]
            return{
                objects: contacts3

            }
           


    
        default:
            return initState;
    }
}

// export const reducer = combineReducers({
//     rootReducer: rootReducer,
//     add_contact: add_contact
// })