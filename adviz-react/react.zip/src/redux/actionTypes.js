export const ADD_CONTACT = 'ADD_CONTACT'
export const UPDATE = 'UPDATE'
export const CLICK_CONTACT = 'CLICK_CONTACT'
export const DELETE = 'DELETE'