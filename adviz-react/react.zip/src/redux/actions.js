import { ADD_CONTACT, UPDATE, CLICK_CONTACT, DELETE } from "./actionTypes";

export const add_contact = (contact) => ({type: ADD_CONTACT, payload: contact}) 

export const click_contact = (key_index) => ({type: CLICK_CONTACT, payload: key_index})

export const update = (contact) => ({type: UPDATE, payload: contact})

export const delete_ = () => ({type: DELETE, payload: 1})

