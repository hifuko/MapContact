import React, {Component} from 'react';
import { add_contact } from './redux/actions'
import { connect } from 'react-redux'


class Add extends Component{

  
    handleAdd = (e) => {
      
    }

    handleSubmit = (e) => {
      e.preventDefault()

      let firstName = document.querySelector("#fn2").value;
      let name = document.querySelector("#n2").value;
      let street = document.querySelector("#street2").value;
      let postCode = document.querySelector("#pc2").value;
      let city = document.querySelector("#city2").value;
      let country = document.querySelector("#country2").value;
      // "private" is a reserved word 
      let private_ = document.querySelector("#pr2").checked;
  
  
      let myObj = {
          "firstName": firstName,
          "name": name,
          "street": street,
          "postCode": postCode,
          "city": city,
          "country": country,
          "private_": private_
      };
  
      

      let myJSON = JSON.stringify(myObj);
      localStorage.setItem("person_" + firstName + " " + name, myJSON);

      //this.props.handleAddContact(myObj)

      //store.dispatch(add_contact(myObj))
      this.props.add_contact(myObj)
  

      document.querySelector("#addNewAddress").style.display = "none";
      document.querySelector("#main").style.display = "block";
      document.querySelector("#addform").reset();

    }
  

    handleBackClick = (e) => {
      document.querySelector("#addNewAddress").style.display = "none";
      document.querySelector("#main").style.display = "block";
      document.querySelector("#addform").reset();

    }
   

    render(){
      
      return(
        <section id="addNewAddress">
    
          <div class="add">
            <h1 style={{"text-align": "center"}}>Add new addresses</h1>

            <form id="addform" action={this.handleAdd} onSubmit={this.handleSubmit} method="GET" class="add_form">
              <table>
                <tr>
                    <td><label for="fn2">First Name</label></td>
                    <td><input type="text" name="firstName" pattern="[a-zA-Z]*" id="fn2" required/></td>
                </tr>
                <tr>
                    <td><label for="n2">Name</label></td>
                    <td><input type="text" name="name" pattern="[a-zA-Z]*" id="n2" required/></td>
                </tr>
                <tr>
                    <td><label for="street2">Street</label></td>
                    <td><input type="text" name="street" id="street2" required/></td>
                </tr>
                <tr>
                    <td><label for="pc2">Post Code</label></td>
                    <td><input type="text" name="postCode" id="pc2" pattern="[0-9]{5}" required/></td>
                </tr>
                <tr>
                    <td><label for="city2">City</label></td>
                    <td><input type="text" name="city" id="city2" pattern="[a-zA-Z]*" required/></td>
                </tr>
                <tr>
                    <td><label for="country2">Country</label></td>
                    <td><input type="text" name="firstName" id="country2" pattern="[a-zA-Z]*" required/></td>
                </tr>
                <tr>
                    <td><label for="pr2">private</label></td>
                    <td><input type="checkbox" name="private_" value="yes" id="pr2" style={{"zoom" : "1.5"}}/></td>
                </tr>

              </table>
              <div align="center">
              {/* onClick={() => this.props.handleAddContact(this.state.newObj)} */}
                <input id="add_btn" class="btn" type="submit" value="Add"/>
                <button class="btn" id="back2" onClick={this.handleBackClick}>back</button>
              </div>
            </form>
          </div>
        </section>

         
      
            
        );
      }
    
    
}

export default connect(
  state=>state,
  {add_contact}
)(Add);