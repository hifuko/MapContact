import React, { Fragment } from 'react'
import {Marker} from 'react-leaflet';

const Markers = () => {
  let lat = 52.520815;
  let lng = 13.409419;

  const markers = <Marker position={[lat,lng]} />
  // todo make markers an array of all adresses
  // check if adress is private and if user is admin
  return <Fragment>{markers}</Fragment>
};

export default Markers;