import React, {Component, Fragment} from 'react';
import axios from 'axios';
import { render } from 'react-dom'
import { Map, Marker, Popup, TileLayer } from 'react-leaflet'

const adressMap = L.map('map', {
        center: [52.520815, 13.409419],
        zoom: 13
       })

L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', { 
        attribution: 'Map data © <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery (c) <a href="https://www.mapbox.com/">Mapbox</a>',
        maxZoom: 18, 
        id: 'mapbox/streets-v11', 
        accessToken: 'your.mapbox.access.token' }).addTo(adressMap);

        const marker = L.marker([37.7544, -122.4477]).bindPopup("marker").addTo(mymap);


const position = [52.520815, 13.409419]
        const map = (
          <Map center={position} zoom={13}>
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution="&copy; <a href=&quot;http://osm.org/copyright&quot;>OpenStreetMap</a> contributors"
            />
            <Marker position={position}>
              <Popup>A pretty CSS3 popup.<br />Easily customizable.</Popup>
            </Marker>
          </Map>
        )
        
        render(map, document.getElementById('map-container')){
                return(
                <body>
                        <div id="osm-map"></div>
                </body>);
        
        };

const Ninjas = ({ninjas, deleteNinja}) => {
  return (
    <div className="ninja-list">
      { 
        ninjas.map(ninja => {
          return (
            <div className="ninja" key={ninja.id}>
              <div>Name: { ninja.name }</div>
              <div>Age: { ninja.age }</div>
              <div>Belt: { ninja.belt }</div>
              <button onClick={() => {deleteNinja(ninja.id)}}>Delete ninja</button>
            </div>
          )
        })
      }
    </div>
  );
}

export default Ninjas

export default class Map extends Component{

        componentDidMount() {
                // Where you want to render the map.
                let element = document.getElementById('osm-map');

                // Height has to be set. You can do this in CSS too.
                element.style = 'height:400px;';

                // Create Leaflet map on map element.
                let map = L.map(element);

                // Add OSM tile leayer to the Leaflet map.
                L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
                        attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
                }).addTo(map);

                // Initial marker
                let target = L.latLng('52.520815', '13.409419');
                // L.marker(target).addTo(map);
                map.setView(target, 12);

                populateMap();
        }

        componentDidUpdate() {
                populateMap();
        }

        const position = [52.520815, 13.409419]
        const map = (
          <Map center={position} zoom={13}>
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution="&copy; <a href=&quot;http://osm.org/copyright&quot;>OpenStreetMap</a> contributors"
            />
            <Marker position={position}>
              <Popup>A pretty CSS3 popup.<br />Easily customizable.</Popup>
            </Marker>
          </Map>
        )
        
        render(map, document.getElementById('map-container')){
                return(
                <body>
                        <div id="osm-map"></div>
                </body>);
        
        };



        render(){
                return(
                <body>
                        <div id="osm-map"></div>
                </body>
        );
      }

 
      

populateMap = () => {
        let keys = Object.keys(localStorage);
        keys.forEach(function (id) {
                if (id.match(/person_.*/g)) {
                        let jsonString = localStorage.getItem(id);
                        let object = JSON.parse(jsonString);
                        if (object.private == false) {
                                putMarker(id);
                        } else if (object.private == true && this.sessionStorage.getItem("currentUserRole") === "admin") {
                                putMarker(id);
                        }
                }
        });
};

putMarker = id => {
        (async () => {
                let geodata = await resolveAddress(id);
                if (geodata == false) {
                        return;
                }
                let target = L.latLng(geodata[0], geodata[1]);
                let marker = L.marker(target);
                marker.addTo(map);
        })();
}

resolveAddress = id => {
        let jsonString = localStorage.getItem(id);
        let object = JSON.parse(jsonString);
        let street = object.street;
        street = street.replace(/ /g, '+');
        let postcode = object.postCode;
        let url = "https://nominatim.openstreetmap.org/search?postalcode=" + postcode + "&street=" + street + "&format=json&addressdetails=1";
        console.log(id + " " + url);

        return fetch(url)
                .then(function (response) {
                        return response.json();
                })
                .then(function (jsonResponse) {
                        if (jsonResponse == false || typeof (jsonResponse) == "undefined") {
                                return false;
                        }
                        let lat = jsonResponse[0].lat;
                        let lon = jsonResponse[0].lon;
                        return [lat, lon];
                });
}

// window.addEventListener('storage', function (e) {
//         populateMap();     
// });

}

export default Map;