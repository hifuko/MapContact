import React, { Component } from 'react'
import { Map, TileLayer } from 'react-leaflet'
import 'leaflet/dist/leaflet.css';
import Markers from './Markers';
import L from 'leaflet';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

class MapView extends Component {

    // todo subscribe to redux states

    constructor(props) {
        super(props);
        this.state = {
            lat: 52.520815,
            lng: 13.409419,
            zoom: 12,
        }
    }
    
    render() {
        const { lat,lng,zoom } = this.state;
        let DefaultIcon = L.icon({
            iconUrl: icon,
            shadowUrl: iconShadow
        });
        L.Marker.prototype.options.icon = DefaultIcon;
        
        return (
            <Map 
            center={ [lat,lng] } 
            zoom={ zoom } 
            style={{ width: '100%', height: '100%'}}>
            <TileLayer
                attribution='&copy <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/>
                <Markers init={ [lat,lng] } />
            </Map>
        )
     }
 }

 export default MapView;