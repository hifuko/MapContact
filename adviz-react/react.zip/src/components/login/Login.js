import React, {Component} from 'react';
import store from '../../redux/store'
import {push} from 'react-router-redux';




export default class Login extends Component{
    constructor(){
        super()
    
        this.adminUser = {
          username: "admin",
          password: "admin",
          role: "admin"
        };
      
        this.normalUser = {
            username: "normalo",
            password: "normalo",
            role: "user"
        };
      
        this.userList = [this.adminUser, this.normalUser];

        // if (sessionStorage.getItem("loggedIn") === "true") {
        //   document.querySelector("#login").style.display = "none";
        //   document.querySelector("#main").style.display = "block";
  
        //   if (sessionStorage.getItem("currentUserRole") === "user") {
        //       //normalo don't have add, update, delete buttons
        //       document.querySelector("#add_menu_btn").style.display = "none";
        //       document.querySelector("#update").style.display = "none";
        //       document.querySelector("#delete").style.display = "none";
  
        //   }
        // }
    
        
      }
    
    
      
    
      handleSubmit = (e) => {
        e.preventDefault()
        // let un = document.loginform.username.value;
        // let pw = document.loginform.password.value;
        let un = document.querySelector("#un").value;
        let pw = document.querySelector("#pw").value;
    
        for (let user of this.userList) {
            if (user.username === un && user.password === pw) {
                sessionStorage.setItem("currentUserRole", user.role);
                sessionStorage.setItem("loggedIn", true);
                document.querySelector("#login").style.display = "none";
                document.querySelector("#main").style.display = "block";
            
                return;
            }
        }
    
        alert("Wrong username or password");
        return;
      }
      
    
      render(){
        return(
          <section id="login">
            <main>
              <h1>Login</h1>
            
              {/* <form name="loginform" class="loginform" action="javascript:void(0);" method="GET"> */}
              <form name="loginform" class="loginform" onSubmit={this.handleSubmit} method="GET">
                  <div>
                      <input id="un" type="text" name="username" required="true" pattern="[a-zA-Z]*" placeholder="default"/>
                      <label>Username</label>
                  </div>
                  <div>
                      <input id="pw" type="password" name="password" required="true" pattern=".*" placeholder="user"/>
                      <label>Password</label>
                  </div>
                  <div>
                      <input id="login_btn" type="submit" class="btn" value="Login"/>
                  </div>
              </form>
            </main>
          </section>
        );
      }
    
    
}