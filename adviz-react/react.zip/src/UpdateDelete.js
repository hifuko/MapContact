import React, {Component} from 'react';
import { update, delete_ } from './redux/actions'
import { connect } from 'react-redux'

//import PubSub from 'pubsub-js';



class UpdateDelete extends Component{

    handleAction = (e) => {
      
      }
   
    handleBackClick = (e) => {
        e.preventDefault()
        document.querySelector("#updateDeleteAddress").style.display = "none";
        document.querySelector("#main").style.display = "block";

    }

    isNull(str) {
        if (str === "") {
            return true;
        }
        var regu = "^[ ]+$";
        var re = new RegExp(regu);
        return re.test(str);
    }

    update = (e) => {
        let key = this.props.contact_id

        let firstName = document.querySelector("#fn").value;
        let name = document.querySelector("#n").value;
        let street = document.querySelector("#street").value;
        let postCode = document.querySelector("#pc").value;
        let city = document.querySelector("#city").value;
        let country = document.querySelector("#country").value;
        // "private" is a reserved word 
        let private_ = document.querySelector("#pr").checked;
    
        let fn_test = /^[a-zA-Z]+$/.test(firstName);
        let n_test = /^[a-zA-Z]+$/.test(name);
        let street_test = !this.isNull(street);
        let pc_test = /^[0-9]{5}$/.test(postCode);
        let city_test = /^[a-zA-Z]+$/.test(city);
        let country_test = /^[a-zA-Z]+$/.test(country);

        if (fn_test && n_test && street_test && pc_test && city_test && country_test) {

            let myObj = {
                "firstName": firstName,
                "name": name,
                "street": street,
                "postCode": postCode,
                "city": city,
                "country": country,
                "private_": private_
            };
    
            let myJSON = JSON.stringify(myObj);
        
            //In case that firstname or name is updated
            localStorage.removeItem(key)
            let newKey = "person_" + firstName + " " + name
            localStorage.setItem(newKey, myJSON);
    
            this.props.update(myObj)
            
           
    
            // PubSub.publish("update", {
            //     index: this.props.index,
            //     myObj: myObj
            // })
            //this.props.update(this.props.index, myObj)
        
    
            document.querySelector("#addNewAddress").style.display = "none";
            document.querySelector("#main").style.display = "block";
    
        }
        
                
    }
      

    delete = (e) => {
        let key = this.props.contact_id
        localStorage.removeItem(key)
        
        //PubSub.publish("delete", this.props.index)

        //this.props.delete(this.props.index)
        this.props.delete_()

        document.querySelector("#addNewAddress").style.display = "none";
        document.querySelector("#main").style.display = "block";

    }


    render(){
    return(
        <section id="updateDeleteAddress">
            <div class="up">
            <h1 style={{"text-align": "center"}}>Update/Delete address</h1>
            <form action={this.handleAction} onSubmit={this.handleBackClick} method="GET" class="up_form">
                <table>
                <tr>
                    <td><label for="fn">First Name</label></td>
                    <td><input type="text" name="firstName" id="fn" pattern="[a-zA-Z]*" required/></td>
                </tr>
                <tr>
                    <td><label for="n">Name</label></td>
                    <td><input type="text" name="name" id="n" pattern="[a-zA-Z]*" required/></td>
                </tr>
                <tr>
                    <td><label for="street">Street</label></td>
                    <td><input type="text" name="street" id="street" required/></td>
                </tr>
                <tr>
                    <td><label for="pc">Post Code</label></td>
                    <td><input type="text" name="postCode" id="pc" pattern="[0-9]{5}" required/></td>
                </tr>
                <tr>
                    <td><label for="city">City</label></td>
                    <td><input type="text" name="city" id="city" pattern="[a-zA-Z]*" required/></td>
                </tr>
                <tr>
                    <td><label for="country">Country</label></td>
                    <td><input type="text" name="firstName" id="country" pattern="[a-zA-Z]*" required/></td>
                </tr>
                <tr>
                    <td><label for="pr">Private</label></td>
                    <td><input type="checkbox" name="private" id="pr" value="yes" style={{"zoom": "1.5"}}/></td>
                </tr>

                </table>
                <div style={{"padding-left": "120px"}}>
                <button class="btn" id="update" onClick={this.update}>Update</button>
                <button class="btn" id="delete" onClick={this.delete}>Delete</button>
                <button class="btn" id="back" onClick={this.handleBackClick}>back</button>

                </div>


            </form>
            </div>


  </section>

        );
      }
    
    
}

export default connect(
    state=>state,
    {update, delete_}
  )(UpdateDelete);

