import React, {Component} from 'react';

export default class Nav extends Component{
   
      
      render(){
        return(
            <nav>
                <ul id="navigation">
                <li><a href="#login">Login</a></li>
                <li><a href="#main">Main Screen</a></li>
                <li><a href="#addNewAddress">Add New Addresses</a></li>
                <li><a href="#updateDeleteAddress">Update / Delete Addresses</a></li>
                </ul>
            </nav>
        );
      }
    
    
}